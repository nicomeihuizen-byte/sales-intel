-- Clears the false "edited" marker on every seeded note.
--
-- scripts/seed.ts backdated created_at but let updated_at default to
-- now(), so each note looked edited weeks after it was written.
-- components/NoteList.tsx shows "edited" whenever updated_at is more than
-- a second after created_at, which was true for every seeded row.
--
-- Safe to run: it only touches notes whose two timestamps disagree, and
-- it sets updated_at to the note's own creation time. A note you have
-- genuinely edited since seeding would be reset too, so run it right
-- after a seed rather than weeks later.
update notes
set updated_at = created_at
where updated_at <> created_at;
