# Patch: seeded notes no longer claim to be edited

One file, plus one SQL statement to fix the rows already in your databases.

```
scripts/seed.ts
```

## What your screenshot caught

Every note on the deal page reads "edited". Nothing was.

`scripts/seed.ts` backdates a note's `created_at` to its place in the timeline but let
`updated_at` default to `now()`. So a note written three weeks ago in the story was stamped
as updated today, and `NoteList` shows "edited" whenever those two timestamps differ by more
than a second. Which was every seeded note, in both databases.

It matters more than it looks on a case-study page: "edited" on every line quietly says
somebody has been rewriting the history the AI then reasons about.

## Fixing the rows you already have

No re-seed needed. Run this in the SQL editor, on **hosted and local both**
(`fix-edited-markers.sql` in this zip is the same thing):

```sql
update notes
set updated_at = created_at
where updated_at <> created_at;
```

Run it soon after seeding rather than later: it would also reset the marker on a note you
have genuinely edited since.

For local, the SQL editor is at http://127.0.0.1:54323 while the stack is running.

Re-take the deal-page screenshot afterwards. The other two shots are unaffected.

## Verified

- `tsc --noEmit` clean, `eslint .` clean.
- The statement is idempotent and scoped by its own `where`: running it twice changes nothing
  the second time.
- **Not verified: the SQL against a live database.** It is three lines and reversible only by
  a re-seed, so read it before you run it.

## Suggested commit

```
fix(seed): stamp updated_at to match created_at on seeded notes

updated_at defaulted to now() while created_at was backdated, so every
seeded note differed from its own creation time and rendered as
"edited" in the timeline.
```
