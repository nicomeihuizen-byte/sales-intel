# Patch: three panes, and editable deal status

Copy over the top. No new dependencies, nothing to delete.

## Apply order, which now matters in both places

```
npm run db:backup
npm run db:migrate
```

`db:migrate` is new in this patch and it is the one to use from now on: it applies only the
pending migrations and **leaves your data alone**. `db:reset` destroys everything and rebuilds
from scratch. I told you to use `db:reset` in the last patch, which was the wrong command for
a database with your real pipeline in it. `npm run db:migrations` lists what's applied if
you want to check first.

**Then, before you push**, paste the new migration into the hosted project's SQL editor:

```sql
alter table deals drop constraint if exists deals_status_check;

alter table deals
  add constraint deals_status_check
  check (status in ('open', 'won', 'lost'));
```

That's the step that broke the demo last time. Hosted has no migration history, so every
schema change goes there by hand before the code that depends on it goes live.

## What changed

**Three panes**: companies, then that company's contacts, then its deals. The notes and the
Analyze panel move to a full-width block underneath rather than a fourth column. A note is a
paragraph and the three panes above are lists; a timeline squeezed into a quarter of the
width makes the one thing you actually read the hardest to read. The shell widens to
`max-w-7xl` to fit, and the panes stack on narrow screens.

**Deal status is editable**, from a dropdown on each deal row and on the deal's full page. It
saves on change, no confirm click. The picker sits beside the deal link rather than inside it,
because a `select` nested in an anchor is invalid HTML and the two fight over the click. The
side effect is useful: you can reclassify a deal without opening it.

**Three statuses, not four.** You listed open/closed/won/lost; the app has open, won and lost,
and I've kept it that way per your answer. Worth remembering why it isn't cosmetic: the status
decides which question the AI asks. Marking a deal won swaps the momentum read for a win
analysis, marking it lost swaps it for a loss post-mortem.

**A CHECK constraint on `deals.status`**, which is the other half of that. Until now the column
was bare text with no constraint, so a bad value would have been accepted and then silently
fallen through to the momentum branch in `app/api/insight/route.ts`, asking "is this stalling?"
about a closed deal with nothing to indicate anything went wrong. Now the database refuses it.

If the migration fails, some row already holds a value outside the three. Find it first with
`select distinct status from deals;` rather than forcing it.

## Verified

- `tsc --noEmit` clean, `eslint .` clean, `next build` compiled and generated all routes.
- The constraint migration applied twice in a row against a real Postgres 16, and the check
  itself was tested: `'closed'` is rejected with a constraint violation, `'won'` is accepted.
- **Not verified: how it looks.** No browser here, so the three-pane layout has been compiled
  but never rendered. The middle pane is the one I'd check first, since contacts with long
  LinkedIn URLs now live in a narrower column than the screenshot you sent.

## Suggested commit

```
feat(companies): three-pane layout and editable deal status

Splits the companies view into companies, contacts and deals across
three columns, moving the selected deal's notes and Analyze panel to a
full-width block underneath where a timeline is actually readable.

Deal status becomes editable from the deals pane and the deal page,
saving on change. Adds a CHECK constraint on deals.status: the value
decides which question the insight route asks the model, so an
unrecognised status would have silently produced a momentum read on a
closed deal.

Adds db:migrate and db:migrations scripts, and documents that
db:migrate rather than db:reset is how a change reaches a database
holding real data.
```
