# Patch: no inner scroll panes at all

Three files. No migration, no env change.

```
app/companies/page.tsx
app/globals.css
components/ContactList.tsx
```

Applies cleanly alongside the seed-dates patch; they touch different files.

## What changed

Every inner scroll container is gone. There were three:

- the deals pane, fixed to three rows
- the company list, capped at 60vh
- the contacts list, capped at 26rem

All three now run their natural length, and the page scrolls as one thing under the wheel.
The `.scroll-quiet` helper I added an hour ago has no users left, so it's out of
`globals.css` too.

I had the previous patch half right. Removing the deals pane's cap was correct; keeping the
company list scrollable was me solving a problem you don't have. Eight companies fit on a
screen, and a pane that scrolls independently means the wheel does different things depending
on where the pointer happens to be, which is worse than a slightly longer page.

The honest cost, for when it eventually bites: at forty companies the left column will be
taller than the screen and you'll be scrolling the whole page to reach the bottom of a list
while the panes beside it scroll away too. That's the point to reintroduce one container, on
the company list only. Not before.

## Verified

- `tsc --noEmit` clean, `eslint .` clean, `next build` compiled and generated all routes.
- Grepped the whole of `app/` and `components/` afterwards: no `overflow-y-auto`, no
  `max-h-`, no `maxHeight` left anywhere.
- **Not verified: how it scrolls.** No browser here.

## Suggested commit

```
style: remove every inner scroll pane

The deals pane, company list and contacts list each had their own
height cap and scroll container. A pane that scrolls independently
makes the wheel do different things depending on where the pointer is,
which costs more than a longer page. All three now run their natural
length and the page scrolls as one.
```
